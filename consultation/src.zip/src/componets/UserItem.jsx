import React from 'react'

function UserItem({user}) {
  return (
    <div>
      <h1>{user.name}</h1>
    </div>
  )
}

export default UserItem
