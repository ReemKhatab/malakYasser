export const Stadiums = [
    {
      id: 1,
      name: "Cairo Stadium",
      rows: 5,
      columns:6,
      numberOfSeats:30,
    },
    {
      id: 2,
      name: "Alex Stadium",
      activated: false,
      rows: 5,
      columns:6,
      numberOfSeats:30,
    },
    {
      id: 3,
      name: "Suez Stadium",
      activated: true,
      rows: 5,
      columns:6,
      numberOfSeats:30,
    },
   
  ];
  