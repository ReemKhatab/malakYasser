export const Managers = [
    {
      id: 1,
      name: "malak",
      activated: false,
    },
    
    {
      id: 4,
      name: "fouda",
      activated: false,
    },
  ];
  