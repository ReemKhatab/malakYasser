export const Users = [
  {
    id: 1,
    name: "malak",
    activated: false,
  },
  {
    id: 2,
    name: "reem",
    activated: false,
  },
  {
    id: 3,
    name: "mohamed",
    activated: true,
  },
  {
    id: 4,
    name: "fouda",
    activated: false,
  },
];
