import React from "react";

import EFAManagerNavBar from "../componets/EFAManagerNavBar";
function EFAManager() {
  return <div></div>;
}

export default EFAManager;
